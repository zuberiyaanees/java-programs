package com.example.Calcdtoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalcdtoappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalcdtoappApplication.class, args);
	}

}

package com.example.Calcdtoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalcdtoappApplicationTests {

	@Test
	void contextLoads() {
	}

}
